﻿namespace Smart_Home
{
	internal static class Constants
	{
		public const int MarkiseMaxWindSpeed = 30;
		public const bool MarkiseCanBeUsedInRain = false;
	}
}
